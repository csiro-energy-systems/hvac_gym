# Created by wes148 at 12/05/2022
from __future__ import annotations

import json
import os
import warnings
from datetime import datetime
from pprint import pformat
from typing import Callable, Optional

import brickschema
import networkx as nx
import pandas as pd
import rdflib
import requests
from loguru import logger
from pandas import DataFrame
from pydantic import BaseModel
from rdflib import BRICK, Literal, URIRef
from rdflib.term import BNode
from requests.auth import HTTPBasicAuth
from urllib3.util import parse_url

from dch.dch_model_utils import briql_response_to_df, flatten, rename_columns, shorten, split_path_string
from dch.paths.dch_paths import SemPath
from dch.senaps_interface import SenapsInterface
from dch.utils.data_utils import resample_and_join_streams


class DCHBuilding(BaseModel):
    """Class to represent a building for the DCH API."""

    org: str
    site: str
    building: str
    tz: Optional[str] = None  # noqa

    def __init__(self, org, site, building, tz=None):
        super().__init__(org=org, site=site, building=building, tz=tz)

    def __repr__(self):
        return str(self)

    def __str__(self):
        return f"{self.org}.{self.site}.{self.building}"


class DCHInterface:
    """
    Class to facilitate interaction with the DCH Building Service Layer (BSL) API.
    Based on https://bitbucket.csiro.au/projects/SBDCH/repos/dch-application-examples/raw/external/vbis-tag_retreival_Lady_Huntingfield/interface
    .py?at=refs%2Fheads%2Fmaster
    API doc: https://dataclearinghouse.org/dch/v1/swagger

    Authors
    ------
        Matt Amos (`matt.amos@csiro.au`)
        John McCullock (`john.mccullock@csiro.au`)
        Sam West (`sam.west@csiro.au`)
    """

    def __init__(self, apikey: str | None = None, username: str | None = None, password: str | None = None, dch_host: str = "dataclearinghouse.org", senaps_host: str = "senaps.io"):
        """
        Creates a new DCHInterface object.  Authentication from either an apikey or username/password pair. If credentials are not provided as
        constructor arguments, this will attempt to load them
        from a .env key-value pair, or environment variables, looking for keys: DCH_UN & DCH_PW or DCH_API_KEY

        :param apikey:
        :param username:
        :param password:
        :param dch_host:
        :param senaps_host:
        """
        if apikey is None and username is None and password is None:
            from dotenv import load_dotenv

            load_dotenv(f"{os.getcwd()}/.env", verbose=True)  # take environment variables from .env in current working dir.
            username, password, apikey = os.getenv("DCH_UN"), os.getenv("DCH_PW"), os.getenv("DCH_API_KEY")

        if username is not None:
            logger.trace(f"Authenticating with DCH API via username: {username}")
        elif apikey is not None:
            logger.trace(f"Authenticating with DCH API via apikey: ...{apikey[-4:]}")
        else:
            raise RuntimeError("No authentication credentials provided or found in environment variables or .env file!")

        self._dch_url = "https://" + dch_host + "/dch/v1"
        self._api_text = "[DCH]"
        self._token = self._generate_oath_token(apikey, username, password)
        self._headers = {"Authorization": f"Bearer {self._token}"}

        self.senaps = SenapsInterface()

    def _generate_oath_token(self, apikey: str = None, username: str = None, password: str = None) -> str:
        """
        Function to generate oauth token for a user, from apikey or username/password.

        Parameters
        ----------
        `apikey` : `str`
        `username` : `str`
        `password` : `str`
        `return` : `token str`
        """
        url = self._dch_url + "/oauth_token"
        if apikey:
            self._headers = {"X-Api-Key": apikey}
            req = requests.get(url, headers=self._headers)
            if not req.ok:
                raise Exception(f"{self._api_text}({req.text})\n{self._api_text} Failed '{url}'\nUnable to generate oauth token. Ensure valid API key has been " f"" f"" f"" f"" f"" f"" f"used.")
            return req.json()["access_token"]
        else:
            req = requests.get(url, auth=HTTPBasicAuth(username, password))
            if not req.ok:
                raise Exception(f"{self._api_text}({req.text})\n{self._api_text} Failed '{url}'\nUnable to generate oauth token. Ensure correct username and " f"password have been entered.")
            return req.json()["access_token"]

    def create_user_query(self, query: dict) -> dict:
        """
        Function to add a user-specified query to the Building Service Layer (BSL).

        Parameters
        ----------
        `query` : `dict`
            Input arguments to parse using argparse
        `return` : `argparse.Namespace`
            Namespace representation of the processed input arguments.
        """
        url = self._dch_url + "/query/user/equip_and_points"
        req = requests.put(url, data=json.dumps(query), headers=self._headers)
        if not req.ok:
            raise Exception(f"{self._api_text}({req.text})\n\n{self._api_text} Failed '{url}'\n\nUnable to add user query. Ensure correct authorisation provided.")
        return req.json()

    def briql_query(self, query: dict) -> dict:
        """
        Function to apply a query to the BSL using BRIQL.

        Parameters
        ----------
        `query` : `dict`
            BRIQL query to apply to the Building Service Layer.
        `return` : `dict`
            JSON-interpreted response of the query request result.
        """
        url = self._dch_url + "/query"
        req = requests.post(url, data=json.dumps(query), headers=self._headers)
        if not req.ok:
            raise Exception(f"{self._api_text}({req.text})\n\n{self._api_text} Failed '{url}'\n\nUnable to perform BRIQL query. Ensure correct username and " f"password have been entered.")
        return req.json()

    def get_organisations(self) -> list:
        """
        Gathers available organisations given a user's permissions.

        Parameters
        ----------
        `return` : `list`
            JSON-interpreted list of organisations available for the user to inspect.
        """
        url = self._dch_url + "/orgs"
        req = requests.get(url, headers=self._headers)
        if not req.ok:
            raise Exception(
                f"{self._api_text}({req.text})\n\n{self._api_text} Failed '{url}'\n\nUnable to gather organisations. Ensure correct username and "
                f"password have been entered, and you have used an "
                f"oauth token."
            )
        return req.json()

    def request(self, url: str, method: str, **kwargs):
        """
        Makes a request to the DCH API.
        :param url: URL to request
        :param method: the http method to use (e.g. GET, POST, PUT, DELETE)
        :param kwargs: any additional arguments to pass to the request.  A 'headers' key will be merged with the default headers.
        :return:
        """
        headers = dict(kwargs.pop("headers", {}), **self._headers)
        req = requests.request(method, url, headers=headers, **kwargs)
        if not req.ok:
            raise Exception(
                f"{self._api_text}({req.text})\n\n{self._api_text} Failed '{url}'\n\nError during request. Ensure correct username and password "
                f"have been entered, and you have used an oauth token."
            )
        return req.json() if req.headers["Content-Type"] == "application/json" else req.text

    def get_building_model(self, building: DCHBuilding, **kwargs) -> dict:
        """
        Gets the entire semantic model for a building.
        :param building:
        :return:
        """
        url = self._dch_url + f"/org/{building.org}/site/{building.site}/building/{building.building}/published"
        return self.request(url, "GET", **kwargs)

    def get_buildings(self, org_id: str, site_id: str) -> list:
        """
        Gathers available buildings given a user's permissions.
        :return:
        """
        url = self._dch_url + f"/org/{org_id}/site/{site_id}/buildings"
        return self.request(url, "GET")

    def get_dch_buildings(self, orgs: list[str] | None = None, sites: list[str] | None = None) -> list[DCHBuilding]:
        """
        Gets DCHBuilding objects for buildings from the given organisations and sites.
        :param orgs: list of organisation IDs to get buildings for.  If None, gets all organisations (if you have appropriate permissions).
        :param sites: list of site IDs to get buildings for.  If None, gets all sites (if you have appropriate permissions).
        :return: list of DCHBuilding objects
        """
        if orgs is None and sites is not None:
            raise ValueError("If sites are specified, orgs must also be specified")

        if orgs is None and sites is None:
            orgs = self.get_organisations()

        if sites is None:
            sites = [site for org in orgs for site in self.get_sites(org)]

        buildings = [DCHBuilding(org, site, building) for org in orgs for site in sites for building in self.get_buildings(org, site)]

        return buildings

    def get_sites(self, orgid: str) -> list:
        """
        Gathers available organisations given a user's permissions.

        Parameters
        ----------
        `orgid` : `str`
            Organisation ID to gather all site IDs for.
        `return` : `list`
            JSON-interpreted list of sites available for the requested organisation.
        """
        url = self._dch_url + f"/org/{orgid}/sites"
        req = requests.get(url, headers=self._headers)
        if not req.ok:
            raise Exception(
                f"{self._api_text}({req.text})\n\n{self._api_text} Failed '{url}'\n\nUnable to get site. Ensure correct username and password have "
                f"been entered, and you have gathered an oauth token."
            )
        return req.json()

    def get_site(self, orgid: str, siteid: str) -> dict:
        """
        Gathers available information on a site given a user's permissions.

        Parameters
        ----------
        `orgid` : `str`
            Organisation ID of the relevant site.
        `siteid` : `str`
            Site ID to gather information for.
        `return` : `list`
            JSON-interpreted dictionary of available information on a site given a user's permissions.
        """
        url = self._dch_url + f"/org/{orgid}/site/{siteid}"
        req = requests.get(url, headers=self._headers)
        if not req.ok:
            raise Exception(
                f"{self._api_text}({req.text})\n\n{self._api_text} Failed '{url}'\n\nUnable to get site. Ensure correct username and password have "
                f"been entered, and you have gathered an oauth token."
            )
        return req.json()

    def get_timeseries(self, **kwargs):
        return self.senaps.get_observations(**kwargs)

    def get_by_brick_class(self, location: DCHBuilding, query_name: str, point_types: list[BRICK] | None = None) -> dict:
        """
        Gets all paths at the given location that match the given brick class(es).

        :param location: DCH organisation id, site id and building id
        :param query_name: name of the query, arbitrary human readable string
        :param point_types: a list of brick classes to match
        :return: a dictionary of the query result
        """
        models = {"models": [{"org_id": location.org, "site_id": location.site, "building_id": location.building}]}

        query = {
            "query_def": {
                "mode": "select",
                "variables": [{"var_type": "node", "name": query_name, "output": True, "fetch": ["id"], "brick_types": [{"match": "isa", "type": shorten(t)} for t in point_types]}],
            }
        }
        models.update(query)
        return self.briql_query(models)

    def get_children(self, dch_building: DCHBuilding, node_id: str = None) -> dict:
        """
        Queries the semantic model for the given building to get all children, optionally starting from given node id.
        :param dch_building: the building to query
        :param node_id: the node id to start from. If None, returns the whole building's model.
        :return: JSON semantic building model for all children
        """
        query = {
            "describe": {
                "model_ref": {"org_id": dch_building.org, "site_id": dch_building.site, "building_id": dch_building.building},
            }
        }
        if node_id is not None:
            query["describe"]["node_id"] = node_id
        return self.briql_query(query)

    def get_building_graph(self, dch_building: DCHBuilding) -> brickschema.Graph:
        """
        Gets the semantic model for a building as an RDF graph.
        :param dch_building: the building to query
        :return: an RDF graph of the building model
        """
        building_model_ttl = self.get_building_model(dch_building, headers={"Accept": "text/turtle"})

        brick_graph = rdflib.Graph()
        brick_graph.parse(data=building_model_ttl, format="turtle")

        return brick_graph

    def to_networkx(self, rdf_graph: brickschema.Graph, edge_predicates: list[URIRef] | None = None, shorten_uris: bool = True) -> nx.DiGraph:
        """
        Exports the graph as a NetworkX DiGraph placing edges between nodes related by the given list of BRICK predicates.
        Remaining predicate:objects are added as attributes to the subject node.

        Note: the current syntax for some objects (e.g. `[ brick:value 1 ]` ) causes RDFLib to insert a BNode UID as the object.  This method
        will dereference these and add the BNode's predicate:object pairs as attributes to the subject node (e.g. convert the above example to '1').

        :param rdf_graph: the RDF graph to export
        :param edge_predicates: the list of predicates to use filters on edges between nodes.  If None, defaults to [BRICK.hasPoint,
        BRICK.isPointOf, etc]
        :param shorten_uris: whether to shorten the URIs to just the fragment (e.g. "AHU_B1" instead of
        "dch:org/csiro/site/clayton/building/Building307#AHU_B1")
        :return graph (networkx.DiGraph): networkx object representing this graph
        """
        if edge_predicates is None:
            edge_predicates = [BRICK.hasPoint, BRICK.isPointOf, BRICK.feeds, BRICK.isFedBy, BRICK.hasPart, BRICK.isPartOf]

        g = nx.DiGraph()

        def shorten(uri: URIRef):
            """Converts URIRefs and Literals to str for readability"""
            if not shorten_uris:
                return uri
            if uri is None:
                return None
            if isinstance(uri, Literal):
                return str(uri)
            if not (isinstance(uri, URIRef)):
                return uri
            fragment = parse_url(uri).fragment
            return fragment if fragment else uri

        def add_triples(g, s, p, o):
            """Adds a triple to the networkx graph, only creating edges from predicates in edge_predicates, other triples end up as node
            properties
            """
            if p in edge_predicates:
                # if it's a BRICK predicate we care about, add an edge between subject and object named with the predicate
                g.add_edge(s, o, name=p)
            else:
                # otherwise, add the predicate:object pair as an attribute to the subject node
                g.add_node(s, name=s)
                g.nodes[s][p] = o

        for s, p, o in rdf_graph.triples((None, None, None)):
            s, p, o = shorten(s), shorten(p), shorten(o)
            edge_predicates = [shorten(p) for p in edge_predicates]

            # Deal with BNode references inserted by BRICK's [brick:value thing] object syntax
            # We just dereference the UID BNode and add _its_ predicate:object pairs as attributes to the current subject node's properties
            if isinstance(o, BNode):
                bnode_triples = list(rdf_graph.triples((o, None, None)))
                for sb, pb, ob in bnode_triples:
                    add_triples(g, s, p, shorten(ob))
            else:
                add_triples(g, s, p, o)

        return g

    def find_streams_path(
        self, building: DCHBuilding, p: str | list[str] | SemPath, alias: str = "", fetch: list[str] = None, long_format: bool = True, search_variations: bool = False, verbose: int = 0
    ) -> pd.DataFrame:
        """
        Finds all paths and their stream IDs matching the given string of object-predicate pairs, starting from the given building.
        Bick classes, stream_ids and entity properties keys are returned as separate DataFrame columns.

        Example usage:

        >>> building = DCHBuilding("org", "site", "BuildingName")
        >>> stream_df = dch.find_streams_path(building, "Electrical_Meter hasPoint Electrical_Power_Sensor[unit=='unit:KiloW' and
        powerFlow=='export']")
        >>> print(stream_df)
        ...             Electrical_Meter         Electrical_Power_Sensor                     type        unit  ... powerFlow
        ... PV_R_Residential_Test_System   E8_07_PV_HR_ResTest.RealPower  Electrical_Power_Sensor  unit:KiloW  ...    export
        ... PV_R_Residential_Test_System  E8_07_PV_HR_ResTest.RealPowerA  Electrical_Power_Sensor  unit:KiloW  ...    export
        ... PV_R_Residential_Test_System  E8_07_PV_HR_ResTest.RealPowerB  Electrical_Power_Sensor  unit:KiloW  ...    export
        ... PV_R_Residential_Test_System  E8_07_PV_HR_ResTest.RealPowerC  Electrical_Power_Sensor  unit:KiloW  ...    export

        Some example `object_predicate_string`s are:
        - "Building_Electrical_Meter feeds Electrical_Circuit feeds Electrical_Meter hasPoint Power_Sensor" - would find all the power submeters in
        the building.
        - "AHU hasPart Outside_Damper hasPoint Damper_Position_Sensor" - would find all the Air Handling Units' outside air damper positions

        :param p: pairs of space-separated object-predicate strings e.g. "AHU feeds Zone hasPart Chilled_Water_Coil hasPoint
        Valve_Position_Sensor" with an optional filter string suffix e.g. "[unit=='unit:percent']".  The filter must be a valid pandas DataFrame.
        query() string for the resulting dataframe.

        :param alias: optional alias to replace the DCH building prefix with in the cell contents, e.g. "nc:" would replace
        "dch:org/csiro/site/newcastle/building/Newcastle#". None peserves full prefixes. Default (empty string) drops the building prefix entirely
        and abbreviates the full brick prefix to 'brick:' for readability.

        :param fetch: optional list of fields to fetch for the final Object in each result path. Valid values include: ["id", "type", "streams",
        "unit", "entityproperties"].  Returns all these values if `fetch==None`.

        :param long_format: if True (default), converts the resulting DataFrame to long format, with fixed columns for name_path and type_path.
        Useful for later concatenating stream metadata from multiple briql queries together.

        :param search_variations: if True, will search for variations of the given path, e.g. a path like
            "AHU feeds Zone hasPart Chilled_Water_Coil hasPoint Valve_Position_Sensor" would also return results for shortened paths like
                      "Zone hasPart Chilled_Water_Coil hasPoint Valve_Position_Sensor",
                                   "Chilled_Water_Coil hasPoint Valve_Position_Sensor" and
                                                               "Valve_Position_Sensor"
                                                               (the latter will catch 'dangling' valves not associated with any equipment).

        :param verbose whether to print the BRIQL query and results. 0 = no output, 1 = print results

        :return: a pandas DataFrame of matched results, containing columns for all matched path Objects and their names, and a column for their
        stream IDs.
        """
        if isinstance(p, str) or isinstance(p, list):
            point = SemPath(path=p)
        elif isinstance(p, SemPath):
            point = p
        else:
            raise ValueError(f"Invalid path: {p}. Must be str, list, SemPath")

        aliases = {} if alias is None else {f"dch:org/{building.org}/site/{building.site}/building/{building.building}#": alias}
        if alias is not None:
            aliases.update({"https://brickschema.org/schema/Brick#": "brick:"})

        if fetch is None:
            fetch = ["id", "unit", "streams", "type", "unit", "entityproperties"]

        result_df = pd.DataFrame()

        for p in point.path:
            obj_pred_pairs, filter = split_path_string(p)

            if search_variations:
                # creating all shortened variations of the object-predicate pairs, down to the last object by itself
                variations = [obj_pred_pairs[i:] for i in range(len(obj_pred_pairs))]
            else:
                # otherwise just search the given path in its entirety
                variations = [obj_pred_pairs]

            for v in variations:
                query_df = self.briql_path_query(building, v, filter, fetch, aliases, long_format, verbose)

                if search_variations:
                    # Add the exact path variation that was matched to the result
                    query_df["path_variation"] = " ".join([s for s in list(flatten(v)) if s])

                result_df = pd.concat([result_df, query_df])

            result_df["path"] = p

        if search_variations:
            # we'll generally get multiple hits ont he same stream if searching variations. This keeps the longest matching paths only.
            result_df = result_df.drop_duplicates(subset=["streams"], keep="first")

        if verbose:
            print(f"Result:\n{result_df}")

        return result_df

    def briql_path_query(self, building: DCHBuilding, obj_pred_pairs: list[list[str]], filter: str, fetch: list[str], aliases: dict[str], long_format: bool, verbose: int) -> pd.DataFrame:
        # Construct variables clauses from path-string object classes.  Only `fetch` attributes (stream_id, etc) for last object.
        variables = []
        for obj_pred in obj_pred_pairs:
            last_obj = obj_pred == obj_pred_pairs[-1]
            obj = obj_pred[0]
            variables += [{"var_type": "node", "name": str(obj), "output": True, "fetch": fetch if last_obj else ["id"], "brick_types": [{"match": "isa", "type": str(obj)}]}]

        # construct paths clauses from path-string predicates
        paths = []
        for i in range(0, len(obj_pred_pairs) - 1):
            frm = obj_pred_pairs[i][0]
            pred = obj_pred_pairs[i][1]
            to = obj_pred_pairs[i + 1][0]
            paths.append({"from_ref": frm, "to_ref": to, "properties": [{"property": pred}]})

        # construct the BRIQL query
        briql_query = {
            "models": [{"org_id": building.org, "site_id": building.site, "building_id": building.building}],
            "query_def": {"comment": str(obj_pred_pairs), "mode": "select", "variables": variables, "query": {"paths": paths}},
        }
        logger.trace(f"Running BRIQL query:\n {pformat(briql_query, width=200)}")
        resp = self.briql_query(briql_query)
        query_df = briql_response_to_df(resp, aliases=aliases, long_format=long_format)

        # Separate columns for the entity properties
        query_df = self.explode_entity_properties(query_df)

        # Apply filter to dataframe
        if filter is not None and not query_df.empty:
            try:
                query_df = query_df.query(filter)
            except Exception as e:
                logger.error(f'Error applying path search filter for: {obj_pred_pairs}, results may not be accurate.  Filter: "{filter}", error: "{e}"')

        return query_df

    def explode_entity_properties(self, query_df: pd.DataFrame) -> pd.DataFrame:
        """Explodes the 'entity_property' column of a Dataframe into separate columns
        :param query_df: a dataframe with an 'entity_property' column, containing a list of dicts with 'property' and 'value' keys (as returned by
        find_streams_path(), for example)
        :return: a dataframe with the 'entity_property' column exploded into separate columns - with 'property' as column name and 'value' as
        column value
        """
        if query_df is None or len(query_df) == 0 or "entity_property" not in query_df.columns:
            return query_df

        properties = query_df["entity_property"]
        with warnings.catch_warnings():
            warnings.simplefilter("ignore", category=FutureWarning)
            properties_df = properties.apply(lambda row: pd.Series({parse_url(json["property"]).fragment: json["value"] for json in row}))
        result_df = pd.concat([query_df, properties_df], axis=1).drop(columns=["entity_property"])
        return result_df

    def get_df_by_path(
        self,
        *points: str | SemPath,
        building: DCHBuilding,
        start: datetime,
        end: datetime,
        rename_cols: bool = False,
        long_format: bool = False,
        stream_filter: Callable[[DataFrame], DataFrame] = None,
    ) -> dict[str]:
        """Helper method which downloads timeseries data for all streams found matching one or more SemPath paths, resamples them to a common
        sample rate and joins them by timestamp.

        Use this if you're confident all your SemPaths are joinable, and the discovered streams don't need extra filtering etc.

        :param points: SemPaths to find streams for
        :param building: DCHBuilding to search in
        :param start: Start of timeseries data
        :param end: End of timeseries data
        :param rename_cols: whether to rename the columns to the last `Equipment hasPoint Sensor` section of the  SemPath path
        :param stream_filter: a function to filter out matches streams from the stream DataFrame.  See :func:`dch.utils.data_utils.filter_streams`
        for dataframe format.
        :return: dict containing the joined dataframe, stream metadata and estimated common sample rate in minutes. Dict values will be all None if
        no data was found.
        """
        all_stream_meta: list[DataFrame] = []
        all_steam_names: list[str] = []

        for point in points:
            stream_meta = self.find_streams_path(building, point, long_format=long_format)
            stream_meta = stream_filter(stream_meta) if stream_filter is not None else stream_meta
            if len(stream_meta) == 0:
                continue
            unique_streams = stream_meta["streams"].explode().unique()
            all_steam_names.extend(unique_streams)
            all_stream_meta.append(stream_meta)

        if all_stream_meta is None or len(all_stream_meta) == 0:
            return {"data": None, "streams": None, "sample_rate": None}

        all_stream_meta = pd.concat(all_stream_meta).explode("streams")

        result = self.get_df_by_stream_id(all_steam_names, building=building, start=start, end=end)

        if rename_cols:
            result["data"], result["streams"] = rename_columns(result["data"], all_stream_meta)
        else:
            result["streams"] = all_stream_meta

        return result

    def get_df_by_stream_id(
        self,
        *stream_ids: str,
        building: DCHBuilding,
        start: datetime,
        end: datetime,
    ) -> dict[str]:
        dfs = []

        for stream in stream_ids:
            data = self.senaps.get_stream(stream, convert_tz=building.tz, start=start, end=end)
            dfs.extend(data)
        joined, sample_rate_mins = resample_and_join_streams([df for df in dfs if df is not None and not df.empty])

        return {"data": joined, "sample_rate": sample_rate_mins}
