# Created by wes148 at 19/05/2022
import os
from pathlib import Path
from typing import Optional

from loguru import logger


def find_project_root(path: Path = Path("").resolve(), root_file: str = "pyproject.toml") -> Optional[Path]:
    """Finds the first dir, at or above `path`, containing a particular root_file (indicating the root dir of the project), or None if no matching files are found"""
    if len(list(path.glob(root_file))) == 1:
        return path
    elif path.parent.resolve() == path:
        return None  # we've reached the root dir
    else:
        return find_project_root(path.parent.resolve())


def cd_project_root() -> None:
    """Attempts to change working dir to the project root"""

    root = find_project_root()
    if root is not None:
        os.chdir(root)
        logger.trace(f"Set working dir to {os.getcwd()}")
    else:
        logger.warning("Failed to find project root dir!")
