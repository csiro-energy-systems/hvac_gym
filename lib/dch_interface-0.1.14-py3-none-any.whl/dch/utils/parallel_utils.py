# Created by wes148 at 15/12/2021
"""
A collection of utilities for parallel processing (multi-threaded and multi-process).
Created by wes148 at 1/04/2021
"""

import contextlib
import os
import typing
from enum import Enum
from multiprocessing import cpu_count
from typing import Any

import joblib
from joblib import Parallel, delayed, parallel_backend
from loguru import logger
from tblib import pickling_support
from tqdm import tqdm

# Allow limited pickling of exception tracebacks, so they can be returned from workers and handled in the calling thread/process.
pickling_support.install()


class ExceptionHandling(Enum):
    LOG = 1
    THROW = 2
    RETURN = 3
    IGNORE = 4


class JobArgs:
    """
    Little utility class to allow for arguments and keyword arguments to be handled by `parallel_run`
    """

    @typing.no_type_check
    def __init__(self, *args, **kwargs):
        self.args = args
        self.kwargs = kwargs


@contextlib.contextmanager
def tqdm_joblib(tqdm_object: tqdm) -> tqdm:
    """
    Context manager to get joblib to report into tqdm progress bar given as argument.
    Lets you see a progress bar for long-running joblib batches.

    For details, see: https://stackoverflow.com/a/58936697/4771628

    You can use it like this:
    >>>
        with tqdm_joblib(tqdm(desc="My calculation", total=10)) as progress_bar:
            Parallel(n_jobs=16)(delayed(sqrt)(i**2) for i in range(10))

    Or like this:
    >>>
         # Set the default backend for all Parallel() calls in training
        with parallel_backend(backend='loky', n_jobs=min(multiprocessing.cpu_count(), 60)):
            # Add a progress bar for the joblib job completions
            with tqdm_joblib(tqdm(desc="Training", total=n_duids)) as progress_bar:
                # Use the same Parallel worked pool for repeated job dispatches
                with Parallel() as parallel:
                   results += parallel(delayed(self.train_gen)(*job) for job in jobs)
    """

    class TqdmBatchCompletionCallback(joblib.parallel.BatchCompletionCallBack):
        def __call__(self, *args: list[Any], **kwargs: dict[str, Any]) -> joblib.parallel.BatchCompletionCallBack:
            tqdm_object.update(n=self.batch_size)
            return super().__call__(*args, **kwargs)

    old_batch_callback = joblib.parallel.BatchCompletionCallBack
    joblib.parallel.BatchCompletionCallBack = TqdmBatchCompletionCallback
    try:
        yield tqdm_object
    finally:
        joblib.parallel.BatchCompletionCallBack = old_batch_callback
        tqdm_object.close()


def parallel_run(
    parallel_func: typing.Callable,
    jobs: typing.Union[list[JobArgs], list[tuple]],
    progress_bar_desc: str = None,
    debug_as_serial: bool = False,
    on_exceptions: ExceptionHandling = ExceptionHandling.THROW,
) -> list:
    """
    A helper function for running a function on a number of jobs in parallel.
    This implementation uses Joblib, but the actual parallel engine is specified by the caller, for example:

    Example 1: Basic example for using this function
    >>> # First, define your function to run in parallel.
    >>> # Important: write this function outside any classes, otherwise (for multprocessing), you'll end up serialising the entire class and all
    its properties for no reason (which usually breaks).
    >>> def your_func(param1, param2, param3):
    >>>     return slow_operation(param1, param2, param3)
    >>>
    >>> # Then build a list of all the jobs as a list of either: objects (for a single-argument function), tuples (for positional args only) or
    JobArgs objects (for keyword params as well).
    >>> # Each list entry  defines the parameters for the function for a single job.
    >>> jobs = []
    >>> for param1, param2, param3 in your_param_generator:
    >>>     jobs.append(JobArgs(param1, param2, param3, keyword_param='value'))
    >>>
    >>> # Finally, specify the parallel backend to use (generally do this in a top-level class so all underlying parallel calls can re-use the
    worker pool) and pass the function and job list to
    >>> # parallel_run().
    >>> with get_backend(backend='loky'): # can also use: 'threading', 'multiprocessing', 'loky', 'dask'
    >>>     # Run each function as a separate parallel job
    >>>     results_list = parallel_utils.parallel_run(your_func, jobs, progress_bar_desc="Running your_func")

    Example 2: Use a dask.distributed.Client to run the function in a local cluster:
    >>> from es_pytools.parallel.dask_utils import get_local_cluster
    >>>     with get_local_cluster() as cluster, Client(cluster), get_backend('dask'):
    >>>         results = parallel_utils.parallel_run(your_func, jobs)

    For CPU-intensive tasks without much C-code, try with `get_backend(backend='loky')` first.  It can be a bit finicky about pickling things,
    so fall back to 'multiprocessing', which is a bit more
    forgiving. For CPU-intensive tasks with mostly C-code, or IO-intensive tasks, try with `get_backend(backend='threading')` usually works well,
    and is generally easier to get working.

    :param parallel_func: the function to run :param jobs: the jobs ie, a list of parallel_func parameters :param progress_bar_desc: a string
    describing the job, for the progress bar,
    or None to disable the progress bar. :param debug_as_serial: just calls the `parallel_func` directly for each job in a loop, skipping the
    joblib library and fancy exception handling entirely,
    just like if you called your function directly. :param on_exceptions: ExceptionHandling.THROW catches any uncaught exceptions occurring in the
    `parallel_func` running in a worker and throws
    them from the parent process/thread. ExceptionHandling.IGNORE just swallows the exceptions (joblib's default behaviour) and returns None for
    the job ExceptionHandling.LOG catches any worker
    exceptions and just prints them with stack trace to the log. ExceptionHandling.RETURN appends the exceptions to the returned objects from the
    jobs.

    Turn this on for simpler debugging and less convoluted stack-traces when troubleshooting your function.
    :return: list of return values from parallel_func calls. Order of results is backend-specific, but usually same as the `jobs` order.
    """
    result_list = []

    if len(jobs) > 0 and not isinstance(jobs[0], JobArgs) and not isinstance(jobs[0], tuple):
        if not isinstance(jobs[0], tuple):
            # Special case: allow list of objects when calling the function with a single argument, just repack list[objects] as list[JobArgs[obj]].
            jobs = [JobArgs(job) for job in jobs]

    # If args are tuples, pack them into JobArgs
    if isinstance(jobs[0], tuple):
        jobs = [JobArgs(*job) for job in jobs]

    """ Run function directly for easier debugging """
    if debug_as_serial:
        for job in tqdm(jobs, desc=progress_bar_desc, disable=progress_bar_desc is None, total=len(jobs), dynamic_ncols=True):
            result_list.append(parallel_func(*job.args, **job.kwargs))
    else:
        """Run in parallel with Parallel/delayed"""
        with tqdm_joblib(tqdm(desc=progress_bar_desc, disable=progress_bar_desc is None, total=len(jobs))):
            with Parallel() as parallel:
                try:
                    result_list = parallel(delayed(uncaught_exception_handler)(parallel_func, job) for job in jobs)
                except Exception:
                    logger.exception(f'Uncaught error in parallel run "{progress_bar_desc}"')

    exceptions = [r for r in result_list if isinstance(r, Exception)]
    if len(exceptions) > 0:
        if on_exceptions == ExceptionHandling.LOG:
            logger.opt(exception=exceptions[0]).exception("Uncaught exception running parallel jobs")
        elif on_exceptions == ExceptionHandling.THROW:
            logger.warning(f"{len(exceptions)} worker exception caught during parallel run, raising first exception only...")
            raise exceptions[0]
        elif on_exceptions == ExceptionHandling.IGNORE:
            logger.error(f"{len(exceptions)} worker exception ignored during parallel run!")
            pass
        elif on_exceptions == ExceptionHandling.RETURN:
            logger.warning(f"{len(exceptions)} results from parallel run will be returned with results!")
            pass

    return result_list


@typing.no_type_check
def uncaught_exception_handler(func: typing.Callable, job: JobArgs) -> Any:
    """Function wrapper that catches uncaught exceptions from wrapped (joblib-parallelised) func, and returns them instead of throwing them inside
    the worker.
    This means they can be thrown, logger or ignored by the caller, as appropriate, rather than the default joblib behaviour, which is to just
    ignore them (from loky process pools).

    Note that joblib/pickle can't serialise exceptions (which is what usually happens when a worker returns an exception, as below) properly,
    so we rely on
    tblib (https://pypi.org/project/tblib/), which adds support for this.
    """
    try:
        result = func(*job.args, **job.kwargs)
        return result
    except KeyboardInterrupt as e:
        # always re-throw KeyboardInterrupt exception, so the process pool can terminate gracefully
        raise e
    except Exception as e:
        return e


def get_n_jobs() -> int:
    """Gets the default number of jobs for this system.  Equivalent to cpu_count() but capped at 60 on Windows to avoid a python bug"""
    return min(cpu_count(), 60 if os.name == "nt" else cpu_count())


def get_backend(backend: str = "loky", n_jobs: int = get_n_jobs()) -> joblib.parallel_backend:
    """
    Gets a joblib backend
    :param backend: any backend joblib supports.  Usually 'loky' or 'threading'. See parallel_backend doc for more details.
    :param n_jobs: the number of workers in the pool. defaults to cpu_count(), with max of 60 in windows to avoid a python bug.
    """
    if n_jobs == -1:
        n_jobs = get_n_jobs()
    return parallel_backend(backend=backend, n_jobs=n_jobs)
