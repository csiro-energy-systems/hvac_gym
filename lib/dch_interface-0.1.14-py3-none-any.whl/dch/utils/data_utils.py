from __future__ import annotations

from collections import defaultdict
from datetime import datetime

import numpy as np
import pandas as pd
from loguru import logger
from pandas import DataFrame, Series
from scipy.stats import mode


def filter_phases(meter_df: pd.DataFrame) -> pd.DataFrame:
    """Filter out single-phases of multi-phase meters
    E.g. if there are 4 separate sensors for summed ABC phases and also A, B and C phases, this will return only the ABC sensor.
    :param meter_df: DataFrame of meters.  First column must be the Electrical_Meter names to aggregate by.
    :return DataFrame of meters with only the highest phase-count meter for each meter name.
    """
    if meter_df is None or meter_df.empty:
        return meter_df
    if "electricalPhaseCount" not in meter_df.columns:
        logger.warning(f"electricalPhaseCount not found in {meter_df.columns}, cannot filter phases")
        return meter_df
    meter_col = meter_df.columns[0]

    # Filter to only the meters with the maximum phaseCount in each group with the same `meter_col` value
    filtered_meters = meter_df.groupby(meter_col, as_index=False).apply(lambda x: x[x["electricalPhaseCount"] == x["electricalPhaseCount"].max()]).reset_index(drop=True)
    return filtered_meters


def remove_unchanging_values(unclean_df: pd.DataFrame, window_samples: int = 6, round_decimals: int = 1, col_drop_nan_frac: float = 0.8) -> pd.DataFrame:
    """Sliding window to remove periods with unchanging values
    :param unclean_df: DataFrame of values to filter
    :param window_mins: Window size (number of samples)
    :param round_decimals: Number of decimal places to round values to before checking for equality
    :param col_drop_nan_frac: Minimum fraction of a column that are nans, after removals, to drop the whole column.
    :return: DataFrame with unchanging values set to NaN
    """
    t0 = datetime.now()

    if unclean_df is None or unclean_df.empty:
        return unclean_df

    unclean_df = unclean_df.fillna(np.nan)  # make sure None etc are converted to nans before filtering

    nan_count_per_col = unclean_df.isna().sum()

    def detect_constant(window: Series):
        """Returns NaN if the window is constant, else the last value.
        There are faster methods, but not that also deal with existing missing values.
        """
        return np.nan if window.nunique(dropna=False) == 1 else window.iloc[-1]  # noqa

    clean_df = unclean_df.round(round_decimals).rolling(window=window_samples, min_periods=1).apply(detect_constant)  # noqa

    extra_nans = clean_df.isna().sum() - nan_count_per_col
    if extra_nans.sum() > 0:
        logger.warning(f"Removed unchanging values in {len(nan_count_per_col)} columns of dataframe with shape: {unclean_df.shape}: \n{(extra_nans)} in " f"" f"{datetime.now() - t0}")

    # drop columns with more than 80% NaNs (threshold is the minimum number of non-NaN values!)
    clean_df = clean_df.dropna(axis=1, thresh=len(clean_df) - (col_drop_nan_frac * len(clean_df)))

    return clean_df


def remove_dissimilar_cols(df: pd.DataFrame, min_r_squared: float = 0.5) -> pd.DataFrame:
    """Remove columns that have less than min_r_squared maximum cross-correlation with the other columns in the dataframe

    Essentially, 'good' columns are ones which have a maximum correlation with any other column greater than min_r_squared

    This is intended to be used to remove bad sensor readings from a group of similarly-valued sensor columns, like a group of zone temperature
    readings with a few that read abnormally high or low.

    :param df: DataFrame of values to filter
    :param min_r_squared: Minimum average cross-correlation to keep a column
    """
    if len(df.columns) < 3:
        logger.warning(f"Can't identify outlier columns with only {len(df.columns)} columns provided.")
        return df

    corrs = df.corr().to_numpy()
    corrs[np.diag_indices_from(corrs)] = 0  # set (self-correlation) diagonals to zero
    corrs_df = pd.DataFrame(corrs, index=df.columns, columns=df.columns)
    corrs_max = corrs_df.max()

    good_cols = corrs_max.gt(min_r_squared).sort_values()

    if not all(good_cols):
        logger.warning(f"Removed {len(good_cols) - sum(good_cols)} of {df.shape[1]} outlier columns from df: {df.columns[~good_cols].tolist()} with r^2 < " f"{min_r_squared}")

    return df.loc[:, good_cols]


def estimate_sample_rate(stream_series: pd.DataFrame | list[pd.DataFrame]) -> float:
    """Estimate the most common data sample rate from the a collection of time-series dataframes.
    :param stream_series: List of dataframes of time-series data
    """
    if isinstance(stream_series, pd.DataFrame):
        stream_series = [stream_series]
    sample_rates = [round(float(s.index.to_series().diff().median().total_seconds() / 60)) for s in stream_series if s is not None and len(s) > 1]
    sample_rate_mins = np.nan if len(sample_rates) == 0 else round(mode(sample_rates).mode) if len(sample_rates) > 2 else min(sample_rates)

    return sample_rate_mins


def resample_and_join_streams(stream_data_list: list[DataFrame], sample_rate_mins: float | None = None) -> (DataFrame, float):
    """Resamples and joins a list of streams dataframes into a single dataframe with a common datetime index.
    This also preserves the individual DFs' metadata dicts in the joined DataFrame's .attrs dict.

    :param stream_data_list: list of dataframes to resample and join (e.g. from SenapsInterface.download_senaps_stream())
    :param sample_rate_mins: sample rate in minutes to resample to. If None, will estimate the most common sample rate.
    :return: a single dataframe with a common datetime index, and the sample rate in minutes
    """
    if stream_data_list is None or len(stream_data_list) == 0:
        raise ValueError("stream_data_list must contain at least one non-empty dataframe")

    if sample_rate_mins is None:
        # Estimate the most common sample rate, and resample all streams to match
        sample_rate_mins = estimate_sample_rate(stream_data_list)

    if stream_data_list is None or len(stream_data_list) == 0:
        return pd.DataFrame(), sample_rate_mins

    # Resample and concatenate the streams together
    joined_df = pd.concat([s.resample(f"{sample_rate_mins}min").mean() for s in stream_data_list if s is not None], axis="columns", join="inner")

    # preserve the DF's attrs so we can relate (unescaped) column/stream names to the (possibly escaped) stream IDs
    concated_attrs = defaultdict(list)
    for df in stream_data_list:
        for k, v in df.attrs.items():
            concated_attrs[k].append(v)
    joined_df.attrs.update(concated_attrs)

    return joined_df, sample_rate_mins
