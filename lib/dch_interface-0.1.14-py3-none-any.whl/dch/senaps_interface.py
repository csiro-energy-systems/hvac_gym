# Created by wes148 at 20/05/2022
import base64
import json
import os
from collections import defaultdict
from pathlib import Path
from threading import Lock
from typing import Optional, Union

import pandas as pd
import requests
from loguru import logger
from requests.auth import HTTPBasicAuth
from senaps_sensor import API
from senaps_sensor.auth import HTTPKeyAuth
from senaps_sensor.models import Observation, UnivariateResult

from dch.utils.parallel_utils import JobArgs, get_backend, parallel_run

INT32_MAX_VALUE = int(2**32 / 2 - 1)


class SenapsInterface:
    """
    Class to facilitate interaction with the Senaps Sensor API.

    API doc is here: https://senaps.io/api-docs/

    Author
    ------
        Matt Amos (`matt.amos@csiro.au`)
        Sam West (`sam.west@csiro.au`)
    """

    def __init__(self, apikey: Optional[str] = None, username: Optional[str] = None, password: Optional[str] = None, senaps_host: str = "https://senaps.io/api/sensor/v2"):
        """
        Creates a new SenapsInterface object.  Authentication from either an apikey or username/password pair. If credentials are not provided as
        constructor arguments, this will attempt to load them from a .env key-value pair, or environment variables, looking for keys: [SENAPS_UN &
        SENAPS_PW] or SENAPS_API_KEY

        :param apikey:
        :param username:
        :param password:
        :param dch_host:
        :param senaps_host:
        """

        # synchronises concurrent writes from multiple threads to each file. This can happen when there are multiple streams for the same Senaps
        # point.
        self.file_locks = defaultdict(Lock)

        if apikey is None and username is None and password is None:
            from dotenv import load_dotenv

            load_dotenv(f"{os.getcwd()}/.env", verbose=True)  # take environment variables from .env in current working dir.
            username, password, apikey = os.getenv("SENAPS_UN"), os.getenv("SENAPS_PW"), os.getenv("SENAPS_API_KEY")

        if username is not None and password is not None:
            logger.trace(f"Authenticating with Senaps API username: {username}")
            self._headers = {"Content-Type": "application/json", "Authorization": base64.b64encode(bytes(f"{username}:{password}", "UTF-8"))}
            self.sensor_api = API(HTTPBasicAuth(username, password))
        elif apikey is not None:
            logger.trace(f"Authenticating with Senaps API via apikey: ...{apikey[-4:]}")
            self._headers = {"Content-Type": "application/json", "apikey": apikey}
            self.sensor_api = API(HTTPKeyAuth(apikey))
        else:
            raise RuntimeError("No authentication credentials provided or found in environment variables or .env file!")

        self._senaps_url = senaps_host
        self._api_text = "[SENAPS]"

    def _generate_oath_token(self, apikey: str = None, username: str = None, password: str = None) -> str:
        """
        Function to generate oauth token for a user, from apikey or username/password.

        Parameters
        ----------
        `apikey` : `str`
        `username` : `str`
        `password` : `str`
        `return` : `token str`
        """
        url = self._senaps_url + "/oauth_token"
        if apikey:
            self._headers = {"x-Api-Key": apikey}
            req = requests.get(url, headers=self._headers)
            if not req.ok:
                raise Exception(f"{self._api_text}({req.text})\n{self._api_text} Failed '{url}'\nUnable to generate oauth " f"token. Ensure valid API key has been used.")
            return req.json()["access_token"]
        else:
            req = requests.get(url, auth=HTTPBasicAuth(username, password))
            if not req.ok:
                raise Exception(f"{self._api_text}({req.text})\n{self._api_text} Failed '{url}'\nUnable to generate oauth token. Ensure correct username and " f"password have been entered.")
            return req.json()["access_token"]

    def call(self, request_func, endpoint, **kwargs):
        req = request_func(f"{self._senaps_url}/{endpoint}?{'&'.join(map(lambda x: '{}={}'.format(*x), kwargs.items()))}", headers=self._headers)

        if not req.ok:
            raise Exception(f"Failed to call {request_func} with endpoint {endpoint} {req.status_code} ({req.text}))")
        return req.json()

    def get_streams(self, **kwargs):
        """
        Gets all streams.
        Example usage:
        >>> get_streams(id='dsapi*Newcastle*AHU*', expand="True", limit=999)

        :param kwargs: Senaps request parameters. For a list of valid query arguments,
        see: https://senaps.io/api-docs/?urls.primaryName=Sensor%20Data%20API#/default/get_streams
        :return: a dict of streams matching the parameters.
        """
        return self.call(requests.get, "streams", **kwargs)

    def get_observations(self, **kwargs):
        """
        Function to gather observations from Senaps.

        :param kwargs: Keyword arguments to be applied as query arguments to the Senaps request.
          For a list of valid query arguments, see: `https://senaps.io/api-docs/?urls.primaryName=Sensor%20Data%20API#/default/get_observations`

        :return: dict of observations - Response from the observation request, which will contain observations within the `"results"` field.
        """
        # re-encode any datetimes as iso8601 strings
        from datetime import datetime

        for k, v in kwargs.items():
            if isinstance(v, datetime):
                kwargs[k] = v.isoformat()

        if "start" in kwargs and "end" in kwargs:
            if kwargs["start"] > kwargs["end"]:
                raise ValueError(f"start time {kwargs['start']} must be before end time {kwargs['end']}")

        return self.call(requests.get, "observations", **kwargs)

    def delete_observations(self, **kwargs):
        return self.call(requests.delete, "observations", **kwargs)

    def post_observation_pandas(self, stream_id: str, values: pd.Series, **kwargs: dict) -> dict:
        """
        Posts scalar time-series observations from a pandas Series to Senaps.
        See https://senaps.io/api-docs/?urls.primaryName=Sensor%20Data%20API#/default/post_observations

        :param stream_id: the Senaps stream ID to post to
        :param values: a Pandas Series of values to post, indexed by timestamp
        :param kwargs: Keyword arguments to be applied as query arguments to the Senaps request.
        """
        output = Observation()
        output.results = [UnivariateResult(t=t.isoformat(), v={"v": v}) for t, v in values.items()]

        # write the observations to Senaps
        return self.sensor_api.create_observations(output, streamid=stream_id, **kwargs)

    def save_streams(self, stream_patterns: list[str], out_dir: Path = None, write_mode: str = None, convert_tz: str = None, n_jobs=8, **kwargs) -> list[Path]:
        """Saves streams to parquet files and returns the paths to the files.
        Optionally (see `write_mode`) will intelligently update existing parqut files with new data.

        :param stream_patterns: wildcard patterns used ot match stream names.
        :param out_dir: dir to write to, if None just returns the dataframes
        :param write_mode: None to leave all existing files alone, 'overwrite' to just overwrite them, 'update' to append any new data.
        :param convert_tz: IANA timezone string to convert data to, eg 'Australia/Sydney'. Or None to leave as provided timezone.
        :param n_jobs: number of parallel workers with which to download the streams
        :param kwargs: Keyword arguments to be applied as query arguments to the Senaps request. For a list of valid query arguments,
        :returns list of paths to the downloaded parquet files, or dataframes if out_dir is None. Each entry may be None if the stream wasn't
        downloadable.
        See Also: `https://senaps.io/api-docs/?urls.primaryName=Sensor%20Data%20API#/default/get_observations`
        """
        paths, dfs, _ = self.download_senaps_streams(stream_patterns, out_dir, write_mode, convert_tz, n_jobs, **kwargs)
        return paths

    def get_stream(self, stream_patterns: list[str], convert_tz: str = None, n_jobs=8, **kwargs) -> tuple[list[pd.DataFrame], list[str]]:
        """Downloads streams and returns the dataframes

        :param stream_patterns: wildcard patterns used ot match stream names.
        :param convert_tz: IANA timezone string to convert data to, eg 'Australia/Sydney'. Or None to leave as provided timezone.
        :param n_jobs: number of parallel workers with which to download the streams
        :param kwargs: Keyword arguments to be applied as query arguments to the Senaps request. For a list of valid query arguments,
        :returns list of paths to the downloaded parquet files, or dataframes if out_dir is None. Each entry may be None if the stream wasn't
        downloadable.
        See Also: `https://senaps.io/api-docs/?urls.primaryName=Sensor%20Data%20API#/default/get_observations`

        """
        paths, dfs, stream_ids = self.download_senaps_streams(stream_patterns, convert_tz=convert_tz, n_jobs=n_jobs, **kwargs)
        return dfs

    def download_senaps_streams(
        self, stream_patterns: list[str], out_dir: Path = None, write_mode: str = None, convert_tz: str = None, n_jobs=8, verbose=0, **kwargs
    ) -> tuple[list[Path], list[pd.DataFrame], list[str]]:
        """
        Saves all streams matching the given pattern to parquet files, or just returns them as dataframes without saving.
        Optionally (see `write_mode`) will intelligently update existing parqut files with new data.

        :param stream_patterns: wildcard patterns used ot match stream names.
        :param out_dir: dir to write to, if None just returns the dataframes
        :param write_mode: None to leave all existing files alone, 'overwrite' to just overwrite them, 'update' to append any new data.
        :param convert_tz: IANA timezone string to convert data to, eg 'Australia/Sydney'. Or None to leave as provided timezone.
        :param n_jobs: number of parallel workers with which to download the streams
        :param kwargs: Keyword arguments to be applied as query arguments to the Senaps request. For a list of valid query arguments,
        :param verbose: 0 for no progress bar, >0 for progress bar
        :returns (list of paths to the downloaded parquet files, list of dataframes, list of stream IDs. Or `[], [], []` if no streams were
        downloadable.
        See Also: `https://senaps.io/api-docs/?urls.primaryName=Sensor%20Data%20API#/default/get_observations`
        """
        stream_patterns = [s for s in stream_patterns if len(s) > 0]
        if len(stream_patterns) == 0:
            return [], [], []

        # For each pattern in the list, get all matching streams to a single list (found_streams).
        with get_backend("threading", n_jobs=n_jobs):
            found_json = parallel_run(self.get_streams, jobs=[JobArgs(id=sp, expand="True", **kwargs) for sp in stream_patterns], progress_bar_desc="Finding streams" if verbose > 0 else None)

        found_streams: list[dict] = []  # maps stream ID to stream metadata.
        for js in found_json:
            if js["count"] > 0:
                stream_ids = list(js.get("_embedded").get("streams"))
                found_streams.extend(stream_ids)
        logger.trace(f"Found {len(found_streams)} streams in total for patterns: {stream_patterns}")

        if len(found_streams) == 0:
            return [], [], []

        with get_backend("threading", n_jobs=n_jobs):
            results = parallel_run(
                self._save_stream_to_parquet,
                jobs=[JobArgs(stream_json, out_dir, write_mode, convert_tz, **kwargs) for stream_json in found_streams],
                progress_bar_desc="Downloading streams" if verbose > 0 else None,
            )

            paths = []
            dfs = []
            stream_ids = []
            for r in results:
                if r is not None:
                    df, path, stream_id = r
                    df.attrs["stream_id"] = stream_id
                    df.attrs["stream_name"] = df.columns[0] if len(df.columns) > 0 else None
                    paths.append(path)
                    dfs.append(df)
                    stream_ids.append(stream_id)
            return paths, dfs, stream_ids

    def _get_stream_as_dataframe(self, stream_json: dict, convert_tz: str, **kwargs) -> pd.DataFrame:
        """
        Downloads a Senaps stream and returns as a dataframe.

        :param stream_json: the json metadata string returned from the Senaps stream endpoint.
        :param convert_tz: IANA timezone string to convert data to, eg 'Australia/Sydney'.
        :param kwargs: Keyword arguments to be applied as query arguments to the Senaps request.
        :return: stream_df, stream_name, stream_id: a dataframe, the stream name, and the full stream ID
        """
        if stream_json is None:
            raise ValueError("stream_json cannot be None")

        try:
            stream_name = self.get_stream_name(stream_json)
        except ValueError as e:
            logger.warning(f"Invalid stream. {e}")
            return None, None, None

        stream_id = stream_json.get("id")

        """ Download all observations into a dataframe """
        results = self.get_observations(streamid=stream_id, limit=INT32_MAX_VALUE, **kwargs).get("results")
        data = list(map(lambda x: {"t": x.get("t"), "v": x.get("v").get("v")}, results))
        stream_df: pd.DataFrame = pd.DataFrame(data)
        stream_df = stream_df.rename(columns={"v": stream_name})

        """ Make timestamps the index, and convert tz if specified """
        if not stream_df.empty:
            stream_df = stream_df.set_index("t")
            stream_df.index = pd.to_datetime(stream_df.index)
            if convert_tz is not None:
                stream_df.index = stream_df.index.tz_convert(convert_tz)

        return stream_df, stream_name, stream_id

    def _save_stream_to_parquet(self, stream_json: dict, out_dir: Union[Path, str], write_mode: str = None, convert_tz: str = None, **kwargs) -> Optional[tuple[pd.DataFrame, Path]]:
        """
        Saves a stream to disk as a parquet file.
        :param stream_json: JSON metadata for the stream
        :param out_dir: dir to write to
        :param write_mode: None to leave all existing files alone and return the new data, 'overwrite' to just overwrite them, 'update' to append
        any new data.
        :param convert_tz: IANA timezone string to convert data to, eg 'Australia/Sydney'.
        :return a (Dataframe, Path, Str) tuple (respectively: the dataframe, the path saved to or None if out_dir was None, and the full stream
        ID), or None if not downloaded
        """
        stream_df, stream_name, stream_id = self._get_stream_as_dataframe(stream_json, convert_tz, **kwargs)
        if stream_df is None or stream_name is None or stream_df.empty:
            return None

        if out_dir is None:
            return stream_df, None, stream_id

        parq_file = Path(f"{out_dir}/{stream_name}.parquet")
        json_file = Path(f"{out_dir}/{stream_name}.json")

        parq_file.parent.mkdir(parents=True, exist_ok=True)

        if write_mode is None and parq_file.exists():
            """Don't touch existing files"""
            logger.info(f"Not saving data to existing file for stream name: {stream_name}, shape {stream_df.shape}")
            return stream_df, parq_file, stream_id

        else:
            """Save data and metadata"""
            if write_mode == "update" and parq_file.exists():
                lock = self.file_locks[parq_file]
                lock.acquire()
                ex_idx = pd.read_parquet(parq_file, columns=stream_df.index.name)
                stream_df = stream_df[~stream_df.index.isin(ex_idx.index)]  # select df rows that aren't already in ex_idx
                new_rows = stream_df.shape[0]
                if new_rows > 0:
                    ex = pd.read_parquet(parq_file)
                    stream_df = pd.concat([ex, stream_df]).sort_index()
                    stream_df.to_parquet(parq_file)
                    logger.info(f"Appended {new_rows} new rows to existing file {parq_file} for stream name: {stream_name}, shape {stream_df.shape}.")
                    with open(json_file, "w") as f:
                        json.dump(stream_json, f, indent=4, sort_keys=False)
                else:
                    logger.debug(f"No new rows in stream: {parq_file} not updated, name: {stream_name}, shape {stream_df.shape}.")
                lock.release()

                return stream_df, parq_file, stream_id
            else:
                lock = self.file_locks[parq_file]

                lock.acquire()
                stream_df.to_parquet(parq_file)
                with open(json_file, "w") as f:
                    json.dump(stream_json, f, indent=4, sort_keys=False)
                lock.release()

                logger.info(f"Saved data to file {parq_file} for stream name: {stream_name}, shape {stream_df.shape}")

                return stream_df, parq_file, stream_id

        return None

    def get_stream_name(self, stream_json) -> tuple[str, Optional[str]]:
        """
        Gets a unique stream name from various possible versions of the stream json metadata.
        :param stream_json:
        :return: stream name
        :raises ValueError if stream has unknown usermetadata format (usually indicating it's not the expected data format).
        """
        meta = stream_json.get("usermetadata")
        stream_id = stream_json.get("id")
        if meta is None:
            logger.warning(f"Stream {stream_id} has no usermetadata, using stream id as name.")
            return stream_id, None

        parent_name = None
        point_name = None
        if "dchjson" in meta:
            dch = meta["dchjson"]
            point_name = dch["point"]["pointName"]
            parent_name = dch["point"]["parentName"]
        elif "pointName" in meta:
            # Point doesn't have DCH tags, fall back to Senaps tags
            point_name = meta["pointName"]
            parent_name = meta["parentEquipmentName"]
        else:
            logger.warning(f"Stream {stream_id} has unknown usermetadata format. Falling back to stream_name=stream_id.")

        stream_name = parent_name + "." + point_name if parent_name else stream_id

        return stream_name
