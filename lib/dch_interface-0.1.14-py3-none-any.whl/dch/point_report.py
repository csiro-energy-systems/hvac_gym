import pandas as pd
from loguru import logger
from pandas import DataFrame
from tqdm import tqdm

from dch.dch_interface import DCHBuilding, DCHInterface
from dch.paths.dch_paths import SemPath


def building_point_report(buildings: list[DCHBuilding], paths: list[SemPath], search_variations: bool = False, verbose: int = 0) -> tuple[DataFrame, DataFrame]:
    """
    Produces a report on how many matching SemPaths are found in each of on or more buildings.
    :param buildings: a list of DCHBuilding objects
    :param paths: a list of SemPath objects
    :param search_variations: if True, will search for variations of the paths - shortening them by one term at a time up to just the final object
    type.  Only recommended for debugging and model exploration - tends to return lots of false positives for paths ending with non-specific brick
    classes.
    :return: - path_summary a DataFrame with the number of matching paths for each building
             - stream_details a DataFrame with the details of the matching paths
    """
    dch = DCHInterface()

    path_summary = DataFrame()
    matches = []
    for building in buildings:
        for point in tqdm(paths, desc=f"Discovering Points in {building}"):
            try:
                found = dch.find_streams_path(building, point, search_variations=search_variations, long_format=True)
                found["building"] = str(building)
                if not found.empty:
                    matches.append(found)
                path_summary.loc[point.name, "paths"] = str(point.path)
                path_summary.loc[point.name, str(building)] = len(found)

            except Exception as e:
                logger.exception(f"Error searching for {point} in {building}. {e}")

    stream_details = pd.concat(matches) if matches else DataFrame()

    # change dataframe column order so 'paths' column is last
    path_summary = path_summary.reindex(columns=[col for col in path_summary.columns if col != "paths"] + ["paths"])
    path_summary.index.name = "path_name"

    if verbose > 0:
        logger.info(f"Stream Details: \n{stream_details.to_string()}\n")
        logger.success(f"Path Summary: \n{path_summary.to_string()}\n")
    return path_summary, stream_details
