import json
import re
from collections import defaultdict
from collections.abc import Iterable, Sequence
from io import StringIO
from typing import Any, Optional, TypeVar, Union

import networkx as nx
import numpy as np
import pandas as pd
import rdflib
from matplotlib import pyplot as plt
from matplotlib.colors import to_rgba
from rdflib import Graph, URIRef
from rdflib.extras.external_graph_libs import rdflib_to_networkx_digraph
from rdflib.namespace._BRICK import BRICK
from rdflib.plugins.sparql.processor import SPARQLResult

ALL_BRICK_CLASSES = list(vars(rdflib.BRICK)["__annotations__"].keys())
T = TypeVar("T")

# delimiter used to separate invidual BRICK classes/names when constructing path strings.
# Turtle doesn't allow | in entity names (see https://www.w3.org/TR/turtle/#grammar-production-PN_LOCAL) and BRICK classes don't seem to use this,
# so this should allow us to re-split these paths for round-tripping.
path_delimiter = "|"


def sparql_query(query: str, rdf_graph: Graph) -> pd.DataFrame:
    """Run a SPARQL query on the given RDF graph and return the results as a DataFrame"""
    result = rdf_graph.query(query)
    return sparql_result_to_df(result)


def sparql_result_to_df(ttl_results: list[SPARQLResult]) -> pd.DataFrame:
    if len(ttl_results) == 0:
        return pd.DataFrame()
    dfs = []
    for r in ttl_results:
        d = r.asdict()
        short = {k: shorten(v) if isinstance(v, URIRef) else v for k, v in d.items()}
        dfs.append(pd.DataFrame([short]))
    return pd.concat(dfs)


def format_sparql(ttl_results: list[SPARQLResult]) -> str:
    """Formats a list of SPARQLResult objects as a string, shortening URIRefs"""
    s: str = ""
    for r in ttl_results:
        d = r.asdict()
        for k, v in d.items():
            s += f"{k}: {shorten(v) if isinstance(v, URIRef) else v}\n"
        s += "\n"
    return s


def rdf_to_networkx(rdf_graph: Graph, truncate_uris):
    """
    Convert an RDF graph to a networkx graph and populate node attributes from the RDF triples.
    :param rdf_graph: RDF graph to convert
    :param truncate_uris: If True, truncate URIs to just the #<fragment> suffix
    :return: networkx graph
    """

    nx_graph = rdflib_to_networkx_digraph(rdf_graph)

    if truncate_uris:
        # Shorten all the URIs in the graph to just the #fragment suffix
        nx.relabel_nodes(nx_graph, {n: shorten(str(n)) for n in nx_graph.nodes}, copy=False)
        for node1, node2 in nx_graph.edges:
            edge = nx_graph[node1][node2]
            edge["triples"] = [(shorten(s), shorten(r), shorten(o)) for s, r, o in edge["triples"]]

    # Build dict of all rdf_graph's node attributes, keyed by node name, and set on the networkx graph
    attrs = defaultdict(list)
    for s in rdf_graph.subjects():
        for s, p, o in rdf_graph.triples((s, None, None)):
            if truncate_uris:
                attrs[shorten(s)].append((shorten(p), shorten(o)))
            else:
                attrs[s].append((p, o))

    return nx_graph


def briql_response_to_df(result: dict, drop_cols: list[str] = ["var_type", "model_index", "id"], aliases: dict[str, str] = None, long_format: bool = False):
    """
    Converts a BRIQL query result to a DataFrame containing the 'solution_table' and 'solution_nodes' keys if both exist,
    or just the 'solution_nodes' key if not.
    :param result: BRIQL query result containing 'solution_table' and 'solution_nodes' keys
    :drop_cols: list of columns to drop from the DataFrame after processing.  Default is to drop cols that are usually not useful.
    :param aliases: dict of prefix:alias pairs to replace in the cell contents, eg. {"dch:org/csiro/site/newcastle/building/Newcastle#" : "nc"}
    :param long_format: if True, convert the DataFrame to long format, with fixed columns for name_path and type_path.
        Useful for later concatenating stream metadata from multiple briql queries together.
    :return: a DataFrame
    """
    if result is None or len(result) == 0:
        return pd.DataFrame()

    if "solution_table" not in result and "solution_nodes" not in result:
        raise ValueError("Invalid BRIQL result, must contain 'solution_table' and 'solution_nodes' keys")

    if len(result["solution_nodes"]) == 0:
        return pd.DataFrame()

    sol_df = pd.DataFrame()

    # if only a single class was queried we get no solution_table with paths, so just return all json fields as columns
    if "solution_nodes" in result and "solution_table" not in result:
        sol_df = pd.DataFrame(result["solution_nodes"])
        # each column contains dicts now.  split into columns by dict keys
        sol_df = pd.concat([sol_df.drop([col], axis=1).join(sol_df[col].apply(pd.Series)) for col in sol_df.columns], axis=1)
        sol_df = sol_df.reset_index(drop=True)

        # fiddling to make it match the 'solution_table' format below
        if not sol_df.empty:
            sol_df = sol_df.rename(columns={"type": "type_path", "id": "name_path"})
            sol_df["type"] = sol_df["type_path"]
            sol_df = sol_df.drop(columns=["var_type", "model_index"], errors="ignore")
            sol_df = sol_df.reindex(columns=["type_path", "name_path"] + [c for c in sol_df.columns if c not in ["name_path", "type_path"]])

    # if query was of form 'obj pred obj ...' we parse both keys into a single table
    elif "solution_table" in result and "solution_nodes" in result:
        sol_df = pd.read_json(StringIO(json.dumps(result["solution_table"])))

        if sol_df.empty:
            return sol_df

        # just keep the 'full_id' field from each cell's JSON dict
        for col in sol_df.columns:
            sol_df[col] = sol_df[col].map(lambda x: x["full_id"] if isinstance(x, dict) else x)

        # save just the path columns, before attributes are added
        path_cols = sol_df.columns

        # use the last Node's contents to look up the all the keys in the result['solution_nodes'] dict and join them to the DF
        sensor_col = sol_df.columns[-1]
        node_attrs = list(unique(list(flatten([list(v.keys()) for v in result["solution_nodes"][sensor_col].values()]))))
        for attr in node_attrs:
            sol_df[attr] = sol_df.loc[:, sensor_col].apply(lambda node: result["solution_nodes"][sensor_col][node].get(attr))

        if long_format:
            # convert sol_df to name_path (e.g. Chiller1.MSB_E_M2.Apparent_Power) and type_path (e.g.
            # Chiller.Electrical_Meter.Electrical_Power_Sensor) columns,
            # sol_df = sol_df.rename(columns={c: f"{c}_path" for c in path_cols})
            sol_df["name_path"] = sol_df[path_cols].apply(lambda x: path_delimiter.join(x), axis=1)
            sol_df["type_path"] = path_delimiter.join(path_cols)
            sol_df = sol_df.drop(columns=path_cols)
            # move path_cols to the front
            sol_df = sol_df.reindex(columns=["type_path", "name_path"] + [c for c in sol_df.columns if c not in ["name_path", "type_path"]])

        sol_df = sol_df.drop(columns=[c for c in sol_df.columns if c in drop_cols], errors="ignore")

    # rename cell contents matching any of the alias keys to their values
    if aliases is not None:
        for prefix, aliases in aliases.items():
            for col in sol_df.columns:
                sol_df[col] = sol_df[col].map(lambda x: str(x).replace(prefix, aliases) if isinstance(x, str) else x)

    return sol_df


def unique(seq: Sequence[T]) -> list[T]:
    """Fast, order preserving list uniquification.
    See https://www.peterbe.com/plog/fastest-way-to-uniquify-a-list-in-python-3.6
    """
    return list(dict.fromkeys(seq))


def concat_path_dfs(df_list: list[pd.DataFrame]):
    """
    Pivots and concatenates a list of dataframes returned from `find_streams_path()` or `briql_response_to_df()`, adding path_type and path_name
    columns to each.
    :param df_list: list of dataframes returned from `find_streams_path()` or `briql_response_to_df()` to concatenate
    :return: a single concatenated dataframe with columns for path_names and path_types
    """
    modified_dfs = []
    for d in df_list:
        path_df = d.copy()
        brick_class_cols = [c for c in path_df.columns if c not in ["streams"] and is_brick_class(c)]
        for idx, c in enumerate(brick_class_cols):
            path_df[f"path_type_{idx + 1}"] = c
        for idx, c in enumerate(brick_class_cols):
            path_df[f"path_name_{idx + 1}"] = path_df[c]
        path_df = path_df.drop(columns=brick_class_cols)
        modified_dfs.append(path_df)

    stream_df = pd.concat(modified_dfs)
    stream_df = stream_df.reindex(sorted(stream_df.columns), axis=1)
    if "streams" in stream_df.columns:
        stream_df = stream_df.explode("streams")

    return stream_df


def print_path_between(graph: nx.Graph, node1: Any, node2: Any, print_node_attrs: bool = False):
    """
    Prints the shortest path between two nodes in a networkx graph
    """
    print_path(nx.shortest_path(graph, node1, node2), graph, print_node_attrs)


def print_path(path: list, graph: nx.Graph, print_node_attrs: bool = False):
    """
    Prints the path between two nodes in a networkx graph
    :param path: list of nodes in the path
    :param graph: networkx graph
    :return:
    """
    print(path)
    for node1, node2 in zip(path[:-1], path[1:]):
        # get all edge data between these two nodes
        node_attrs = graph.nodes[node2]
        edge_data = graph[node1][node2]
        s, r, o = edge_data["triples"][0]
        print(f"{s:<40} {r:<20} {o:<40}")
        if print_node_attrs:
            # print in dark grey:
            print(f"{node_attrs}\n")


def get_uniform_colormap_samples(cmap_name, n):
    """Returns a list of n RGBA tuples sampled uniformly from the given colormap"""
    cmap = plt.get_cmap(cmap_name)
    samples = np.linspace(0, 1, n)
    rgba_colors = [to_rgba(cmap(sample)) for sample in samples]
    return rgba_colors


def shorten(brick: Union[URIRef, list[URIRef]]):
    """Shortens a full brick URIRef to just its class name."""
    if isinstance(brick, list):
        return " ".join([str(b).split("#")[-1] for b in brick])
    if isinstance(brick, URIRef):
        return str(brick).split("#")[-1]
    else:
        raise ValueError(f"Invalid brick type {type(brick)}")


def format_json(json_str: str):
    """Formats a JSON string with indentation"""
    return json.dumps(json_str, indent=4)


def is_brick_class(brick_class_name: str) -> bool:
    """Checks if a string is a valid BRICK class name"""
    return brick_class_name in ALL_BRICK_CLASSES


def split_path_string(path: str) -> tuple[list[tuple[str, Optional[str]]], Optional[str]]:
    """Splits a path string (a list of space separated BRICK "[subject predicate]* object") into a list of (object, predicate) pairs,
    and an optional filter on the result. The last pair will have a None predicate as it's the object of the path only.

       Example:
       >>> split_path_string("AHU hasPart Hot_Water_Valve hasPoint Valve_Position_Sensor[unit=='%'")
       ... [('AHU', 'hasPart'), ('Hot_Water_Valve', 'hasPoint'), ('Valve_Position_Sensor', None)], "unit=='%'"

       :returns
           - the object-predicate pairs and
           - the filter string, or none if no filter found.
    """

    # copy any substrings in path that are between [ and ] chars into a  new variable called 'filter'
    filtr = re.search(r"\[(.*?)\]", path)
    if filtr is not None:
        filtr = filtr.group(1)
        path = re.sub(r"\[(.*?)\]", "", path)

    obj_pred_tokens = path.split(" ")
    obj_pred_pairs = [tuple(obj_pred_tokens[i : i + 2]) for i in range(0, len(obj_pred_tokens), 2)]
    obj_pred_pairs[-1] = (obj_pred_pairs[-1][0], None)

    return obj_pred_pairs, filtr


def path_to_brick_classes(obj_pred_pairs: list[tuple[str, str]]):
    """Converts a path of (object, predicate) pairs to a list of BRICK classes"""
    [(BRICK[obj], None if pred is None else BRICK[pred]) for obj, pred in obj_pred_pairs]


def flatten(xs: Iterable[Any]) -> Iterable[Any]:
    """Recusively flattens an Iterable of Iterables"""
    for x in xs:
        if isinstance(x, Iterable) and not isinstance(x, (str, bytes)):
            yield from flatten(x)
        else:
            yield x


def rename_columns(stream_data_df: pd.DataFrame, stream_meta_df: pd.DataFrame, prefix_col: Optional[Union[str, int]] = None) -> tuple[pd.DataFrame, pd.DataFrame]:
    """Rename columns to match HVACPoint names - i.e. the last two Brick types from each stream path - this should give us the `Equipment
    hasPart Point` relationship - all we need to match to FDDPoints in the context of an AHU, if the building model follows DCH norms.

    :param stream_data_df: DataFrame containing the stream time-series data.
    :param stream_meta_df: DataFrame containing the stream and path metadata, as returned from `DCHInterface.find_streams_path()`
    :param prefix_col: optional column name (str) or index (int) from the stream_meta_df to prefix the renamed columns with, e.g. 'Zone' for a
    path like 'Zone hasPart Zone_Temperature_Sensor hasPoint Temperature_Sensor'
    :return: a copy of the `stream_data_df` DataFrame with renamed columns, and a copy of the `stream_meta_df` with a new 'column_name' column to track renamed columns
    """
    brick_types = stream_meta_df[[t for t in stream_meta_df.columns if "type" in t]]
    type_strings = brick_types.apply(lambda types: ".".join([t for t in types if t is not None and not pd.isna(t)]), axis=1).to_list()

    if prefix_col is not None:
        prefixes = stream_meta_df[prefix_col].to_list() if isinstance(prefix_col, str) else stream_meta_df.iloc[:, prefix_col].to_list()
        type_strings = [f"{prefix}.{t}" for prefix, t in zip(prefixes, type_strings)]

    # append _N to any duplicates in type_strings
    type_strings = [f"{t}_{type_strings[:i].count(t)}" if type_strings.count(t) > 1 else t for i, t in enumerate(type_strings)]
    renamed = stream_data_df.rename(columns=dict(zip(stream_data_df.columns, type_strings)))
    stream_meta_df["column_name"] = type_strings
    return renamed, stream_meta_df
