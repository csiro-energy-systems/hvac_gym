from typing import Annotated, Optional, Union

from pydantic import BaseModel, Field, model_validator
from rdflib import BRICK, URIRef
from typing_extensions import Self

from dch.dch_model_utils import shorten, split_path_string

brick_class_names = set([shorten(p) for p in dir(BRICK) if isinstance(p, URIRef)])

# Allow extra DCH Brick patch classes.
# See https://bitbucket.csiro.au/projects/SBDCH/repos/brick-patch-private/browse/src/brick_patch/brick_patch.ttl
# TODO Remove these once models are converted to BRICK 2.0, which simplified this class set.
DCH_EXTRA_CLASSES = [
    "Electrical_Circuit",
    "Electrical_Utility_Meter",
    "Electrical_Generation_Meter",
    "Electrical_Storage_Meter",
    "Site_Electrical_Meter",
    "Electrical_Circuit",
    "Solar_Inverter",
    "Battery_Inverter_Charger",
    "Battery_Inverter",
    "AC_Battery",
    "Hybrid_Inverter",
]


class SemPath(BaseModel):
    """
    Container for Sematic Paths, i.e. one or more sequences of Brick classes (paths) which define a path between a piece of equipment and a
    specific sensor/setpoint in a Brick semantic model.

    For example:
        SemPath(path='AHU hasPart Outside_Damper hasPoint Damper_Position_Sensor')

    See SemPaths for more examples

    Multiple search paths may be provided, but they must all start with the same equipment class and end in the same 'equipment_class hasPoint
    point_class' pattern.  That is, an SemPath instance shall only ever refer to a single parent->sensor relationship, but it may search multiple
    paths to discover it.
    """

    # Pydantic config, see https://docs.pydantic.dev/latest/api/config/
    # model_config = ConfigDict(frozen=True) # make immutable

    # A short name for identifying the point concisely.
    # If constructing a new point manually (instead of using a SemPaths entry) the name should always be specified.
    name: Optional[str] = ""

    # The standardised semantic path to the sensor or setpoint in a brick model
    path: Annotated[Union[str, list[str]], Field(default="")]

    # A human-readable description of the point
    desc: Optional[str] = None

    # Whether to validate the component of the string path(s).  Generally want this on, but handy to turn off to create custom (e.g. non-brick) SemPaths.
    validate_path: bool = True

    @model_validator(mode="after")
    def _validate_path(self) -> Self:
        """Always convert any paths that are singleton `str` to `list[str]` for simpler downstream logic"""
        if isinstance(self.path, str):
            self.path = [self.path]

        if isinstance(self.path, list):
            if not all(isinstance(p, str) for p in self.path):
                raise ValueError("All paths must be strings")
            if self.validate_path:
                for path in self.path:
                    self._validate_path_string(path)
        return self

    def _validate_path_string(self, path: str) -> str:
        """Checks that all terms in the path are valid BRICK classes"""
        # TODO: validate filter as well somehow?
        obj_pred_pairs, filtr = split_path_string(path)
        for terms in obj_pred_pairs:
            for term in terms:
                if term is not None and term not in brick_class_names and term not in DCH_EXTRA_CLASSES:
                    raise ValueError(f"Invalid BRICK class name: {term}")

        return path

    def get_type_strings(self) -> list[str]:
        """Gets a '.'-separated string of the Brick classes which define this point.
        E.g. "AHU hasPart Outside_Damper hasPoint Damper_Position_Sensor" would return "AHU.Outside_Damper.Damper_Position_Sensor"
        """
        type_strings = []
        for p in self.path:
            brick_classes = split_path_string(p)
            type_string = ".".join([brick_class[0] for brick_class in brick_classes])
            type_strings.append(type_string)
        return type_strings

    @classmethod
    def instances(cls) -> list:
        """Returns all instances of SemPaths"""
        items = list(cls.__dict__.items())
        return [v for k, v in items if isinstance(v, SemPath)]

    def __or__(self, other: Self):
        """Combine two SemPaths into a new SemPath using a logical OR operator. It will match either of the given Brick path strings"""
        if not isinstance(other, SemPath):
            raise ValueError(f"Can't combine SemPath with {type(other)}")
        return SemPath(path=self.path + other.path, name=f"{self.name} or {other.name}")

    def __len__(self):
        return len(repr(self))

    def __hash__(self):
        """Hash the has of each element in the path list"""
        return sum([hash(p) for p in self.path])

    def __eq__(self, other):
        return hasattr(other, "path") and self.path == other.path

    def __str__(self):
        return f"{self.name}"

    def __repr__(self):
        return f"SemPath({self.name})"
