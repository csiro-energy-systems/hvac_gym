"""A collection of commonly used BRICK Semantic Paths (SemPaths).
These  can be used to find groups of paths associated with specific equipment types in a BRICK model.

These allow app developers to use concise and portable variable names to reference particular paths within a building model, and lets DCH
update the underlying paths for each point as DCH norms and BRICK schemas evolve.

Note that the enum names are used as the SemPath.name when converted with .to_path(), to save double handling when specifying here.
"""

import pandas as pd
from pydantic import BaseModel

from dch.paths.dch_paths import SemPath

filter_net_real = "[powerFlow=='net' and powerComplexity=='real']"
filter_gross_real = "[powerFlow=='gross' and powerComplexity=='real']"
filter_net_reaactive = "[powerFlow=='net' and powerComplexity=='reactive']"

# fmt: off
ahu_intake_temp = SemPath(
    name="ahu_intake_temp",
    path="AHU hasPoint Intake_Air_Temperature_Sensor",
    desc="The outside air intake temperature sensor for an AHU"
    )
ahu_ra_temp = SemPath(
    name="ahu_ra_temp",
    path=["AHU hasPoint Return_Air_Temperature_Sensor", "AHU isFedBy Return_Air_Plenum hasPoint Return_Air_Temperature_Sensor"]
    )
ahu_ma_temp = SemPath(name="ahu_ma_temp", path="AHU hasPoint Mixed_Air_Temperature_Sensor")
ahu_ra_rh = SemPath(
    name="ahu_ra_rh",
    path=["AHU hasPoint Return_Air_Humidity_Sensor", "AHU isFedBy Return_Air_Plenum hasPoint Return_Air_Humidity_Sensor"]
    )
ahu_oa_rh = SemPath(name="ahu_oa_rh", path="AHU hasPoint Outside_Air_Humidity_Sensor")
ahu_room_rh = SemPath(name="ahu_room_rh", path="AHU feeds Room hasPoint Zone_Air_Humidity_Sensor")
ahu_oa_damper = SemPath(name="ahu_oa_damper", path=["AHU hasPart Outside_Damper hasPoint Damper_Position_Sensor"])
ahu_ra_damper = SemPath(name="ahu_ra_damper", path=["AHU hasPart Return_Damper hasPoint Damper_Position_Sensor"])
ahu_sa_temp = SemPath(name="ahu_sa_temp", path="AHU hasPoint Supply_Air_Temperature_Sensor")
ahu_sa_rh = SemPath(name="ahu_sa_rh", path="AHU hasPoint Supply_Air_Humidity_Sensor")
ahu_sa_temp_sp = SemPath(name="ahu_sa_temp_sp", path="AHU hasPoint Supply_Air_Temperature_Setpoint")
ahu_sa_fan_speed_sp = SemPath(name="ahu_sa_fan_speed_sp", path="AHU hasPart Supply_Fan hasPoint Speed_Setpoint")
ahu_sa_fan_speed = SemPath(name="ahu_sa_fan_speed", path="AHU hasPart Supply_Fan hasPoint Speed_Sensor")
ahu_sa_fan_power = SemPath(name="ahu_sa_fan_power", path="AHU hasPart Supply_Fan hasPoint Power_Sensor")
ahu_zone_temp = SemPath(name="ahu_zone_temp", path="AHU feeds Zone hasPoint Zone_Air_Temperature_Sensor", desc="Air temp of a zone fed by an AHU")
ahu_room_temp = SemPath(name="ahu_room_temp", path="AHU feeds HVAC_Zone hasPart Room hasPoint Air_Temperature_Sensor")
generation_meter = SemPath(
    name="generation_meter",
    path="Electrical_Meter hasPoint Electrical_Power_Sensor[unit=='unit:KiloW' and powerFlow=='export']",
    desc="Export real power Submeters within a building"
    )
# TODO differentiate between gross and net meters
building_real_power_meter = SemPath(
    name="building_real_power_meter",
    path=["Building_Electrical_Meter hasPoint Active_Power_Sensor[unit=='unit:KiloW']"],
    desc="Top-level building power meter"
    )
building_reactive_power_meter = SemPath(
    name="building_reactive_power_meter",
    path="Building_Electrical_Meter hasPoint Electrical_Power_Sensor[unit=='unit:KiloV-A_Reactive']",
    desc="Top-level building power meter"
    )
power_meter = SemPath(name="power_meter", path="Electrical_Meter hasPoint Electrical_Power_Sensor", desc="All submeters within a building")
real_power_net_meter = SemPath(
    name="real_power_meter",
    path=[f"Electrical_Meter hasPoint Electrical_Power_Sensor{filter_net_real}", f"Equipment hasPoint Active_Power_Sensor{filter_net_real}",
          f"Electrical_Power_Sensor{filter_net_real}"],
    desc="Net real power submeters within a building"
    )
real_power_gross_meter = SemPath(
    name="real_power_meter",
    path=[f"Electrical_Meter hasPoint Electrical_Power_Sensor{filter_gross_real}", f"Equipment hasPoint Active_Power_Sensor{filter_gross_real}",
          f"Electrical_Power_Sensor{filter_net_real}"],
    desc="Net real power submeters within a building"
    )
reactive_power_meter = SemPath(
    name="reactive_power_meter",
    path=["Electrical_Meter hasPoint Electrical_Power_Sensor[unit=='unit:KiloV-A_Reactive' and powerFlow=='net']",
          "Equipment hasPoint Active_Power_Sensor"],
    desc="Net reactive power submeters within a building", )
chiller_elec_power = SemPath(
    name="chiller_elec_power", path=[
        "Chiller isFedBy Electrical_Meter hasPoint Electrical_Power_Sensor[unit=='unit:KiloW']",  # DCH standard
        "Chiller isFedBy Electrical_Circuit isFedBy Electrical_Meter hasPoint Electrical_Power_Sensor[unit=='unit:KiloW']",  # Legacy DCH
        # "Chiller isMeteredBy Electrical_Meter hasPoint Electrical_Power_Sensor[unit=='unit:KiloW']", # upcoming BRICK 1.3 standard
    ],
    )
chiller_current = SemPath(name="chiller_current", path="Chiller hasPoint Load_Current_Sensor")
chiller_return_temp = SemPath(name="chiller_return_temp", path="Chiller hasPoint Chilled_Water_Return_Temperature_Sensor")
chiller_supply_temp = SemPath(name="chiller_supply_temp", path="Chiller hasPoint Chilled_Water_Supply_Temperature_Sensor")
chiller_flow = SemPath(name="chiller_flow", path="Chiller hasPoint Chilled_Water_Flow_Sensor")
chiller_chws_thermal_power = SemPath(name="chiller_chws_thermal_power", path="Chilled_Water_System hasPoint Thermal_Power_Sensor")

building_oa_temp = SemPath(
    name="building_oa_temp",
    path=["Building hasPoint Outside_Air_Temperature_Sensor", "Weather_Station hasPoint Outside_Air_Temperature_Sensor"]
    )
building_oa_rh = SemPath(
    name="building_oa_rh",
    path=["Building hasPoint Relative_Humidity_Sensor", "Weather_Station hasPoint Relative_Humidity_Sensor"]
    )

oa_rh = SemPath(
    name="oa_rh",
    path=["Equipment hasPoint Outside_Air_Humidity_Sensor", "Outside_Air_Humidity_Sensor"],
    dec="All outside air relative humidity sensors"
    )
oa_temp = SemPath(
    name="oa_temp",
    path=["Equipment hasPoint Outside_Air_Temperature_Sensor", "Outside_Air_Temperature_Sensor"],
    desc="All outside air temperature sensors"
    )

chw_power = SemPath(name="chw_power", path="Chilled_Water_System hasPart Chilled_Water_Loop hasPoint Power_Sensor")
hw_power = SemPath(name="hw_power", path="Hot_Water_System hasPart Hot_Water_Loop hasPoint Power_Sensor")
hw_thermal_power = SemPath(name="hw_thermal_power", path="AHU hasPart Hot_Water_System hasPoint Thermal_Power_Sensor")
ahu_chw_thermal_power = SemPath(name="ahu_chw_thermal_power", path="AHU hasPart Chilled_Water_Coil hasPoint Thermal_Power_Sensor")
ahu_hw_thermal_power = SemPath(name="ahu_hw_thermal_power", path="AHU hasPart Hot_Water_Coil hasPoint Thermal_Power_Sensor")
ahu_oa_temp_sp = SemPath(
    name="ahu_oa_temp_sp",
    path="AHU hasPoint Outside_Air_Temperature_Setpoint",
    desc="Changeover Air Temp from mode MECH_COOLING_RA to MECH_COOLING_OA"
    )
ahu_oa_enth = SemPath(
    name="ahu_oa_enth",
    path="AHU hasPoint Outside_Air_Enthalpy_Sensor",
    desc="Changeover Air Temp from mode MECH_COOLING_RA to MECH_COOLING_OA"
    )
ahu_op_mode_status = SemPath(
    name="ahu_op_mode_status",
    path="AHU hasPoint Operating_Mode_Status",
    desc="Indicates the current operating mode of a system, device or loop"
    )
ahu_enable_status = SemPath(name="ahu_enable_status", path="AHU hasPoint Enable_Status", desc="Whether the ahu is enabled")
ahu_chw_valve_sp = SemPath(name="ahu_chw_valve_sp", path="AHU hasPart Chilled_Water_Coil feeds Chilled_Water_Valve hasPoint Valve_Position_Sensor")
ahu_hw_valve_sp = SemPath(name="ahu_hw_valve_sp", path="AHU hasPart Hot_Water_Coil feeds Hot_Water_Valve hasPoint Valve_Position_Sensor")

zone_oa_rh = SemPath(name="zone_oa_rh", path=["Zone hasPoint Outside_Air_Humidity_Sensor"])
zone_rh = SemPath(name="zone_rh", path=["Zone hasPoint Humidity_Sensor", "Zone_Air_Humidity_Sensor"])
zone_temp = SemPath(name="zone_temp", path=["Zone hasPoint Temperature_Sensor", "Zone_Air_Temperature_Sensor"])
zone_ra_temp = SemPath(name="zone_ra_temp", path=["Zone hasPoint Return_Air_Temperature_Sensor"])

room_temp = SemPath(name="room_temp", path=["Room hasPoint Temperature_Sensor"])
room_rh = SemPath(name="room_rh", path=["Room hasPoint Humidity_Sensor"])


# ahu_ra_damper = SemPath(path="ahu_ra_damper", "Return-Air Damper")
# ahu_avg_zone_temp = SemPath(path="ahu_avg_zone_temp", "Average Zone Air Temp")
# ahu_zone_temp = SemPath(path="ahu_zone_temp", "Zone Air Temp")
# ahu_zone_temp_sp = SemPath(path="ahu_zone_temp_sp", "Zone Air Temp Setpoint")

# Optional - not used for FDD, but can be added for plotting and manual diagnostics
# ahu_power = SemPath(path="ahu_power", "AHU Power")
# ahu_current = SemPath(path="ahu_current", "AHU Current")
# ahu_chw_flow = SemPath(path="ahu_chw_flow", "Chilled Water Flow Rate")
# ahu_hw_flow = SemPath(path="ahu_hw_flow", "Hot Water Flow Rate")
# ahu_chw_energy = SemPath(path="ahu_chw_energy", "Chilled Water Energy")
# ahu_hw_energy = SemPath(path="ahu_hw_energy", "Hot Water Energy")
# ahu_chw_power = SemPath(path="ahu_chw_power", "Chilled Water Power")
# ahu_hw_power = SemPath(path="ahu_hw_power", "Hot Water Power")

# VAV Points
# vav_zone_temp = SemPath(path="vav_zone_temp", "Zone Temp")
# vav_zone_temp_sp = SemPath(path="vav_zone_temp_sp", "Zone Temp Setpoint")
# vav_cool_sp = SemPath(path="vav_cool_sp", "Cooling Setpoint")
# vav_heat_sp = SemPath(path="vav_heat_sp", "Heating Setpoint")
# vav_air_flow = SemPath(path="vav_air_flow", "Airflow Rate")
# vav_air_flow_sp = SemPath(path="vav_air_flow_sp", "Airflow Rate Setpoint")
# vav_discharge_temp = SemPath(path="vav_discharge_temp", "Discharge Air Temp")
# vav_entering_temp = SemPath(path="vav_entering_temp", "Entering Air Temp")
# vav_reheat_valve = SemPath(path="vav_reheat_valve", "Reheat Valve")
# vav_zone_temp_pos_err = SemPath(path="vav_zone_temp_pos_err", "Zone Temp Positive Error")
# vav_zone_temp_neg_err = SemPath(path="vav_zone_temp_neg_err", "Zone Temp Negative Error")
# vav_air_flow_pos_err = SemPath(path="vav_air_flow_pos_err", "Airflow Positive Error")
# vav_air_flow_neg_err = SemPath(path="vav_air_flow_neg_err", "Airflow Negative Error")
# vav_discharge_temp_pos_err = SemPath(path="vav_discharge_temp_pos_err", "Discharge Temp Positive Error")
# vav_discharge_temp_neg_err = SemPath(path="vav_discharge_temp_neg_err", "Discharge Temp Negative Error")
# vav_zone_co2_sp = SemPath(path="vav_co2_sp", "Zone CO2 Setpoint")
# vav_zone_co2 = SemPath(path="vav_co2", "Zone CO2")
# vav_damper_position = SemPath(path="vav_damper_position", "Damper position")

# FCU (Fan Control Unit) paths
# fcu_cc_valve = SemPath(path="fcu_cooling_coil_valve", "Cooling Coil Valve")

# fmt: on


@classmethod
def rename_columns(stream_data_df: pd.DataFrame, stream_meta_df: pd.DataFrame) -> pd.DataFrame:
    """Rename columns to match SemPath names - i.e. the last two Brick types from each stream path - this should give us the `Equipment
    hasPart Point` relationship - all we need to match to SemPaths in the context of an AHU, if the building model follows DCH norms.
    """
    brick_types = stream_meta_df[[t for t in stream_meta_df.columns if "path_type" in t]]
    type_strings = brick_types.apply(lambda types: ".".join([t for t in types if t is not None and not pd.isna(t)]), axis=1).to_list()
    # append _N to and duplicates in type_strings
    type_strings = [f"{t}_{type_strings[:i].count(t)}" if type_strings.count(t) > 1 else t for i, t in enumerate(type_strings)]
    renamed = stream_data_df.rename(columns=dict(zip(stream_data_df.columns, type_strings)))
    return renamed


def get_all_paths() -> list[SemPath]:
    """Return all the SemPaths defined in this module"""
    return [v for k, v in globals().items() if isinstance(v, SemPath)]


class SemPathsDict(BaseModel):
    """Simply packs all the individual pre-defined SemPath instances in sem_paths into a serialisable class. Mainly for emitting as JSON and simply
    iterating over."""

    # add all SEMPath properties of SEMPaths to a dict by name here
    # get all properties of sem_paths
    dch_paths: list[SemPath] = get_all_paths()
