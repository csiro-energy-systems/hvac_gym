# -*- coding: utf-8 -*-

VALID_PROTOCOLS = frozenset(['https', 'http'])
